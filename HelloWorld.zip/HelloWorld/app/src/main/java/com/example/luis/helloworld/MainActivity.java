package com.example.luis.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String text;
    int nbalea;
    EditText champValeurSaisie;
    int valUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        champValeurSaisie  = (EditText) findViewById(R.id.utilisateur);
        valUser = 0;
        nbalea = (int)(Math.random() * (100 + 1));
        text = "";
    }

    public void divination(View view){
        valUser = Integer.parseInt(champValeurSaisie.getText().toString()) ;
        if(valUser<nbalea){ text = "Le nombre aléatoire est plus grand "; }
        if(valUser>nbalea){ text = "Le nombre aléatoire est plus petit "; }
        if(valUser==nbalea){ text = "Félicitations vous avez trouvé le nombre aléatoire : " + nbalea; }
        Toast.makeText(this,text, Toast.LENGTH_LONG).show();
    }


}
