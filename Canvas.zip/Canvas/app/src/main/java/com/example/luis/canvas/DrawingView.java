package com.example.luis.canvas;

import android.annotation.SuppressLint;
import android.content.*;
import android.graphics.*;
import android.util.*;
import android.view.*;

public class DrawingView extends SurfaceView implements SurfaceHolder.Callback {

    DrawingThread dt;
    Paint blue = new Paint();

    public DrawingView(Context context, AttributeSet attr) {
        super(context, attr);
        getHolder().addCallback(this);
    }


    public void surfaceCreated(SurfaceHolder holder) {
        dt = new DrawingThread(holder,this);
        dt.setMyBoolean(true);
        setWillNotDraw(false);
        dt.start();
    }


    public void surfaceDestroyed(SurfaceHolder holder) {
        dt.setMyBoolean(false);
        try { dt.join(); }
        catch (Exception e) { }
    }

    public void onDraw(Canvas canvas){
        int x, y;
        for ( int row = 0;  row < canvas.getWidth();  row++ ) {
            for ( int col = 0;  col < canvas.getHeight();  col++ ) {
                x = 100*col;
                y = 100*row;
                if ( (row % 2) == (col % 2) )
                    blue.setColor(Color.rgb(0,0,0));
                else
                    blue.setColor(Color.rgb(0,0,255));
                canvas.drawRect(x,y,x+100,y+100, blue);
            }
        }
        blue.setColor(Color.rgb(255,0,0));
        canvas.drawCircle(canvas.getWidth()/2,canvas.getHeight()/2,100, blue);
        Bitmap bp = BitmapFactory.decodeResource(getContext().getResources(),R.drawable.unknown);
        canvas.drawBitmap(bp,30,30,blue);
    }

    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
        // Permet de relancer le rendu de la surface s’il y a un changement
        this.invalidate();
    }

}
