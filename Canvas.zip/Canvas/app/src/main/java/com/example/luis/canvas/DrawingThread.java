package com.example.luis.canvas;

import android.graphics.*;
import android.view.SurfaceHolder;

public class DrawingThread extends Thread {

    private boolean myBoolean;
    private SurfaceHolder mySurfaceHolder;
    private DrawingView myDrawingView;

    public DrawingThread(SurfaceHolder s, DrawingView d){
        this.myBoolean = false;
        this. mySurfaceHolder = s;
        this.myDrawingView = d;
    }

    public void run() {
        Canvas c;
        while(myBoolean) {
            c = null;
            try {
                c = mySurfaceHolder.lockCanvas(null);
                synchronized(mySurfaceHolder) {
                    // ici, mettre les méthodes de modification des positions des objets
                    myDrawingView.postInvalidate();
                    // = remplacement de onDraw() (optimisation)
                }
            } finally {
                if( c != null) {
                    mySurfaceHolder.unlockCanvasAndPost(c);
                }
            }
        }
    }

    public void setMyBoolean(boolean b){
        this.myBoolean = b;
    }
}
