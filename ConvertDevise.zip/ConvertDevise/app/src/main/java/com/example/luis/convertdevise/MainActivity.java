package com.example.luis.convertdevise;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView res;
    TextView mon;
    EditText conv;

    RadioButton dve;
    RadioButton evd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        res = findViewById(R.id.resultat);
        mon = findViewById(R.id.monnaie);
        conv = (EditText) findViewById(R.id.conversion);
        dve = findViewById(R.id.dollareneuro);
        evd = findViewById(R.id.euroendollar);

    }

    public void convertir(View view){
        if(dve.isChecked()){
            mon.setText("$");
            res.setText((double)(int)(Double.parseDouble(conv.getText().toString())*0.88*100)/100+ "€");
        }
        if(evd.isChecked()){
            mon.setText("€");
            res.setText((double)(int)(Double.parseDouble(conv.getText().toString())/0.88*100)/100+ "$");
        }

    }
}
