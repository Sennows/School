package com.example.luis.td2;

import android.os.Parcel;
import android.os.Parcelable;

public class Parametres implements Parcelable {

    private int dec;
    private String clair, chiff;

    public Parametres(int dec, String clair, String chiff){
        this.dec = dec;
        this.clair = clair;
        this.chiff = chiff;
    }

    private Parametres(Parcel in) {
        this.dec = in.readInt();
        this.clair = in.readString();
        this.chiff = in.readString();
    }

    public int describeContents(){
        return 0;
    }


    public void writeToParcel(Parcel dest, int flags){
        dest.writeInt(this.dec);
        dest.writeString(this.clair);
        dest.writeString(this.chiff);
    }

    public static final Parcelable.Creator<Parametres> CREATOR = new Parcelable.Creator<Parametres>(){
        public Parametres createFromParcel(Parcel in){
            return new Parametres(in);
        }

        public Parametres[] newArray(int size){
            return new Parametres[size];
        }

    };

    public int getDec(){return this.dec;}
    public void setDec(int d){this.dec = d; }

    public String getClair(){return this.clair;}
    public void setClair(String c){this.clair = c; }

    public String getChiff(){return this.chiff;}
    public void setChiff(String c){this.chiff = c; }

}
