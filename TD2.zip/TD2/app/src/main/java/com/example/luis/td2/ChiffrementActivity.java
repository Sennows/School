package com.example.luis.td2;

import android.content.*;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;

public class ChiffrementActivity extends AppCompatActivity {

    TextView texte;
    TextView texteclair;

    Parametres param;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chiffrement);
        texte = findViewById(R.id.textechiff);

        texteclair = findViewById(R.id.texte);
        Intent myIntent = getIntent();

        param = (Parametres) myIntent.getParcelableExtra("Parametres");

        texteclair.setText(param.getClair());
        texte.setText(param.getChiff());
    }

}
