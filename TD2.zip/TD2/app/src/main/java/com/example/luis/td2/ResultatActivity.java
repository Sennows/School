package com.example.luis.td2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ResultatActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultat);
        Intent intent = getIntent();
        String monTexte = intent.getStringExtra("texteAPasser");
        TextView text = findViewById(R.id.resultat);
        text.setText(monTexte);
    }

    public void retour(View view){
        Intent intent = new Intent(ResultatActivity.this, MainActivity.class) ;
        startActivity(intent) ;
    }


}
