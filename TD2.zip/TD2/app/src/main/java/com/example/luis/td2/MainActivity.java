package com.example.luis.td2;

import android.content.*;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.EditText;

import java.io.InputStream;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private Parametres param;
    EditText clair;
    EditText clairvig;
    EditText decalage;


    EditText chiff;
    EditText chiffvig;
    EditText decalagechiff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        clair = (EditText) findViewById(R.id.clair);
        clairvig = (EditText) findViewById(R.id.clairvig);
        decalage = findViewById(R.id.decalage);
        chiff = (EditText) findViewById(R.id.chiff);
        chiffvig = (EditText) findViewById(R.id.chiffvig);
        decalagechiff = findViewById(R.id.decalagechiff);
        clair.setText(readFile(this, R.raw.ressource));
        this.param = new Parametres(Integer.parseInt(decalage.getText().toString()),clair.getText().toString(),"");
    }

    private String readFile(Context ctx, int ressource) {
        InputStream input = ctx.getResources().openRawResource(ressource);
        Scanner sc = new Scanner(input);
        String line = "";
        while (sc.hasNextLine()){
            line = line + sc.nextLine()+"\n";
        }
        return line;
    }

    public void chiffrage(View view){
        Intent intent = new Intent(MainActivity.this, ChiffrementActivity.class);
        char[] test = this.clair.getText().toString().toCharArray();
        for(int i=0;i<test.length;i++){
            test[i] = (char) (test[i]+Integer.parseInt(decalage.getText().toString()));
        }
        this.param.setChiff(String.valueOf(test));
        intent.putExtra("Parametres",this.param);
        startActivity(intent) ;
    }

    public void chiffragevig(View view){
        Intent intent = new Intent(MainActivity.this, ChiffrementActivity.class);
        char[] tab = this.clairvig.getText().toString().toCharArray();

        String clef = "EXERCICE";
        int compt_clef = 0;
        char[] cle = clef.toCharArray();

        for(int i=0;i<tab.length;i++){
            if(tab[i]!=' ') {
                if(tab[i]>='A' && tab[i]<='Z') tab[i] = (char) (((tab[i]+(int)cle[compt_clef])%26)+65);
                else tab[i] = Character.toLowerCase((char)(((Character.toUpperCase(tab[i])+(int)cle[compt_clef])%26)+65));
                compt_clef++;
                if (compt_clef == cle.length) compt_clef = 0;
            }
        }

        this.param.setChiff(String.valueOf(tab));
        intent.putExtra("Parametres",this.param);
        startActivity(intent) ;
    }

    public void dechiffrage(View view){
        Intent intent = new Intent(MainActivity.this, DechiffrementActivity.class) ;
        char[] test = this.chiff.getText().toString().toCharArray();
        for(int i=0;i<test.length;i++){
            test[i] = (char) (test[i]-Integer.parseInt(decalagechiff.getText().toString()));
        }
        this.param.setClair(String.valueOf(test));
        this.param.setChiff(chiff.getText().toString());
        intent.putExtra("Parametres",this.param);
        startActivity(intent) ;
    }

    public void dechiffragevig(View view){
        Intent intent = new Intent(MainActivity.this, DechiffrementActivity.class) ;
        char[] tab = this.chiffvig.getText().toString().toCharArray();

        String clef = "EXERCICE";
        int compt_clef = 0;
        char[] cle = clef.toCharArray();

        for(int i=0;i<tab.length;i++){
            if(tab[i]!=' ') {
                if(tab[i]>='A' && tab[i]<='Z'){
                    if((tab[i]-(int)cle[compt_clef])<0) tab[i] = (char) (((tab[i]-(int)cle[compt_clef])%26)+65+26);
                    else tab[i] = (char) (((tab[i]-(int)cle[compt_clef])%26)+65);
                }
                else {
                    if((Character.toUpperCase(tab[i])-(int)cle[compt_clef])<0){
                        tab[i] = Character.toLowerCase((char)(((Character.toUpperCase(tab[i])-(int)cle[compt_clef])%26)+65+26));
                    }
                    else tab[i] = Character.toLowerCase((char)(((Character.toUpperCase(tab[i])-(int)cle[compt_clef])%26)+65));
                }
                compt_clef++;
                if (compt_clef == cle.length) compt_clef = 0;
            }
        }

        this.param.setClair(String.valueOf(tab));
        this.param.setChiff(chiffvig.getText().toString());
        intent.putExtra("Parametres",this.param);
        startActivity(intent) ;
    }
}
