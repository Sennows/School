import os,socket,sys


adresse_serveur = ("224.0.0.127", 7182)
ma_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


fork_use = os.fork()

while 1:
    if not fork_use:
        ligne = input()
        ma_socket.sendto(ligne.encode(), adresse_serveur)
    else :
        ligne, data = ma_socket.recvfrom(1500)
        print(ligne.decode())

os.kill(fork_use,9)
ma_socket.close()
