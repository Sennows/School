import os,socket,sys, select

adresse_hote = ''
numero_port = 6688

ma_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM,socket.IPPROTO_TCP)
ma_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
ma_socket.bind((adresse_hote, numero_port))
ma_socket.listen(socket.SOMAXCONN)

surveillance = [ma_socket]
while 1 :
    (evnt_entree,evnt_sortie,evnt_exception) = select.select(surveillance,[],[])
    for un_evenement in evnt_entree:
        if (un_evenement == ma_socket):
            nouvelle_connexion, depuis = ma_socket.accept()
            print ("Nouvelle connexion depuis ", depuis)
            surveillance.append(nouvelle_connexion)
            continue
        ligne = un_evenement.recv(1024)
        if not ligne :
            surveillance.remove(un_evenement)
        else :
            for client in surveillance :
                if client != ma_socket:
                    client.sendall(ligne)

nouvelle_connexion.close()
ma_socket.close()
