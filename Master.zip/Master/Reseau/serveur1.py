import os,socket,sys,struct


ma_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
adresse_serveur = ("", 7182)
gestion_mcast = struct.pack("4sl" , socket.inet_aton("224.0.0.127"),socket.INADDR_ANY)
ma_socket.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,gestion_mcast)
ma_socket.bind(adresse_serveur)

clients = []
 

while 1:
    ligne, adr = ma_socket.recvfrom(1500)
    if adr not in clients :
        clients.append(adr)
    for c in clients :
        if c != adr :
            ma_socket.sendto(ligne,c)
    
